/**
 * 
 */
package com.demo.spring;

/**
 * @author Nanda
 *
 */
public class ProductBean {
	
	public ProductBean() {
		
	}
	
	private String name;
	private String brand;
	
	public ProductBean(String name, String brand) {
		this.name = name;
		this.brand = brand;
	}
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * @return the brand
	 */
	public String getBrand() {
		return brand;
	}
	/**
	 * @param brand the brand to set
	 */
	public void setBrand(String brand) {
		this.brand = brand;
	}
	
	public double calculateDiscount() {
		
		double discount = 0;
		
		while(discount < 5) {
			discount = Math.random() * 100;
		}
		
		return discount;
	}
	
	
	

}
